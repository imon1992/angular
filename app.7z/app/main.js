angular.module("app",[]);//sozdali novii modul
angular.module("app").controller('SettingsController1', SettingsController1);
angular.module("app").controller('SettingsController2', SettingsController2);
function SettingsController1($scope) { //srv modul ili server kotorii uje est
    $scope.name = 'Vsya';
    this.name = 'JOhn Smith';
}
function SettingsController2($scope) { //srv modul ili server kotorii uje est
    var self = this;
    this.names = [];
    $scope.names = []
    this.addName = function(fname){
        self.names.push(fname);
        $scope.names.push(fname);
    }

    this.deleteName = function(id){
        self.names.splice(id,1);
    }

    
}